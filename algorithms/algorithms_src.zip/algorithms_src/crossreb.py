#!/usr/bin/env python3
"""
crossreb.py — два книжных сигнала BTC (и др.) up/down 15m, тейкер.

Сигналы (path BTC 15m, ROI net после taker+builder≥2%):
  1) CROSS — mid стороны сначала был ≤ CROSS_BELOW, затем ВПЕРВЫЕ mid ≥ CROSS_THR
     при ask ≤ CROSS_MAX_ASK, доля окна ∈ [CROSS_FRAC_LO, CROSS_FRAC_HI].
     Дефолт: below=0.65, thr=0.70, max_ask=0.80 → ~60–70/день, WR~78%, ROI~+2.5%.
  2) REBOUND — mid стороны был ≤ REB_MIN_LOW, затем ask впервые в [REB_LO, REB_HI]
     при frac ≥ REB_FRAC_MIN.
     Дефолт: low=0.25, ask 0.70–0.85, frac≥0.50 → ~20/день, WR~80%, ROI~+3%.

ONE_PER_REASON=true: каждый тип не чаще 1 раза на окно; разные reason не блокируют друг друга.
Конфиг: crossreb.env | ENV_FILE=...  PAPER=true по умолчанию.
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
import os
import signal as _signal
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests
import websockets

ENV_FILE_USED = ""


def _load_env() -> None:
    global ENV_FILE_USED
    explicit = os.environ.get("ENV_FILE", "").strip()
    here = Path(sys.argv[0]).resolve().parent if sys.argv and sys.argv[0] else Path.cwd()
    stem = Path(sys.argv[0]).stem if sys.argv and sys.argv[0] else "crossreb"
    cands = [Path(explicit)] if explicit else [
        here / f"{stem}.env", here / ".env", Path.cwd() / f"{stem}.env", Path.cwd() / ".env",
    ]
    for p in cands:
        try:
            if not p.is_file():
                continue
        except OSError:
            continue
        for raw in p.read_text().splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            if line.lower().startswith("export "):
                line = line[7:].strip()
            k, v = line.split("=", 1)
            k, v = k.strip(), v.strip()
            if v[:1] in ("'", '"') and v[-1:] == v[:1] and len(v) >= 2:
                v = v[1:-1]
            else:
                cut = v.find(" #")
                if cut >= 0:
                    v = v[:cut].rstrip()
            os.environ[k] = v
        ENV_FILE_USED = str(p)
        return
    if explicit:
        raise SystemExit(f"ENV_FILE={explicit} не найден")


_load_env()


def _env(k: str, d: str = "") -> str:
    return os.environ.get(k, d).strip()


def _f(k: str, d: float) -> float:
    v = _env(k)
    return float(v) if v else d


def _i(k: str, d: int) -> int:
    v = _env(k)
    return int(float(v)) if v else d


def _b(k: str, d: bool) -> bool:
    v = _env(k).lower()
    return d if not v else v in ("1", "true", "yes", "on")


class Cfg:
    PAPER = _b("PAPER", True)
    PK = _env("PK")
    FUNDER = _env("FUNDER")
    SIGNATURE_TYPE = _i("SIGNATURE_TYPE", -1)
    API_KEY = _env("CLOB_API_KEY")
    API_SECRET = _env("CLOB_API_SECRET")
    API_PASSPHRASE = _env("CLOB_API_PASSPHRASE")
    HOST = _env("CLOB_HOST", "https://clob.polymarket.com")
    CHAIN_ID = _i("CHAIN_ID", 137)
    GAMMA = _env("GAMMA_HOST", "https://gamma-api.polymarket.com")
    WS_URL = _env("WS_URL", "wss://ws-subscriptions-clob.polymarket.com/ws/market")

    ASSETS = [a.strip().lower() for a in _env("ASSETS", "btc").split(",") if a.strip()]
    TFS = [int(x) for x in _env("TFS", "15").replace(" ", "").split(",") if x]

    # --- CROSS ---
    ENABLE_CROSS = _b("ENABLE_CROSS", True)
    CROSS_BELOW = _f("CROSS_BELOW", 0.65)      # mid must have been ≤ this
    CROSS_THR = _f("CROSS_THR", 0.70)          # then first touch mid ≥ this
    CROSS_MAX_ASK = _f("CROSS_MAX_ASK", 0.80)
    CROSS_FRAC_LO = _f("CROSS_FRAC_LO", 0.15)
    CROSS_FRAC_HI = _f("CROSS_FRAC_HI", 0.92)

    # --- REBOUND ---
    ENABLE_REBOUND = _b("ENABLE_REBOUND", True)
    REB_MIN_LOW = _f("REB_MIN_LOW", 0.25)      # mid was ≤
    REB_LO = _f("REB_LO", 0.70)
    REB_HI = _f("REB_HI", 0.85)
    REB_FRAC_MIN = _f("REB_FRAC_MIN", 0.50)

    MAX_SPREAD = _f("MAX_SPREAD", 0.06)
    REM_MIN_FRAC = _f("REM_MIN_FRAC", 0.08)    # not last 8% of window
    END_GUARD_S = _f("END_GUARD_S", 15.0)
    ONE_PER_REASON = _b("ONE_PER_REASON", True)
    ONE_SIDE_PER_WINDOW = _b("ONE_SIDE_PER_WINDOW", False)
    COOLDOWN_S = _f("COOLDOWN_S", 3.0)

    DEPOSIT = _f("DEPOSIT", 100.0)
    STAKE_PCT = _f("STAKE_PCT", 3.0)
    COMPOUND = _b("COMPOUND", True)
    COMPOUND_FROM = _env("COMPOUND_FROM", "")
    REASONS = ("cross", "rebound")
    SLIP = _f("SLIP", 0.02)
    CAP_PX = _f("CAP_PX", 0.92)
    FEE_RATE = _f("FEE_RATE", 0.07)
    BUILDER_FEE = _f("BUILDER_FEE", 0.01)
    MIN_SHARES = _f("MIN_SHARES", 5.0)
    MIN_USDC = _f("MIN_USDC", 1.0)

    RESOLVE_BY_BOOK = _b("RESOLVE_BY_BOOK", True)
    BOOK_WIN_PX = _f("BOOK_WIN_PX", 0.99)
    BOOK_HOLD_S = _f("BOOK_HOLD_S", 3.0)
    RESOLVE_DELAY_S = _f("RESOLVE_DELAY_S", 60.0)
    RESOLVE_TIMEOUT_S = _f("RESOLVE_TIMEOUT_S", 7200.0)
    WS_STALE_S = _f("WS_STALE_S", 25.0)
    PREROLL_S = _f("PREROLL_S", 20.0)
    DISCOVERY_EVERY_S = _f("DISCOVERY_EVERY_S", 10.0)
    EVAL_EVERY_S = _f("EVAL_EVERY_S", 0.5)

    JOURNAL = _env("JOURNAL", "crossreb.jsonl")
    LOG_LEVEL = _env("LOG_LEVEL", "INFO")


log = logging.getLogger("crossreb")


def _fnum(v: Any) -> Optional[float]:
    try:
        return None if v in (None, "") else float(v)
    except (TypeError, ValueError):
        return None


def _reason_key(reason: str) -> str:
    return (reason or "").strip().lower().replace("-", "_")


def _deposit_for(reason: str) -> float:
    k = "DEPOSIT_" + _reason_key(reason).upper()
    v = _env(k)
    return float(v) if v else Cfg.DEPOSIT


def _stake_pct_for(reason: str) -> float:
    k = "STAKE_PCT_" + _reason_key(reason).upper()
    v = _env(k)
    return float(v) if v else Cfg.STAKE_PCT


def _compound_for(reason: str) -> bool:
    k = "COMPOUND_" + _reason_key(reason).upper()
    v = _env(k).lower()
    if not v:
        return Cfg.COMPOUND
    return v in ("1", "true", "yes", "on")


def _ts_from(s: str) -> float:
    if not s:
        return 0.0
    try:
        return float(s)
    except ValueError:
        pass
    import datetime as _dt
    d = _dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    if d.tzinfo is None:
        d = d.replace(tzinfo=_dt.timezone.utc)
    return d.timestamp()


class Journal:
    def __init__(self, path: str):
        self.path = Path(path)
        self.lock = asyncio.Lock()

    async def write(self, rec: dict) -> None:
        rec = {"ts": round(time.time(), 3), **rec}
        if EQUITY is not None and rec.get("event") in Equity.EVENTS:
            EQUITY.on_rec(rec)
        line = json.dumps(rec, ensure_ascii=False, default=str)
        async with self.lock:
            await asyncio.to_thread(self._append, line)

    def _append(self, line: str) -> None:
        with self.path.open("a") as f:
            f.write(line + "\n")


class Equity:
    EVENTS = ("resolved", "resolved_fix")

    def __init__(self):
        self.by_reason: Dict[str, Dict[tuple, float]] = {r: {} for r in Cfg.REASONS}
        self.since = _ts_from(Cfg.COMPOUND_FROM)

    def on_rec(self, r: dict) -> None:
        if r.get("event") not in self.EVENTS or r.get("pnl") is None:
            return
        if float(r.get("ts") or time.time()) < self.since:
            return
        reason = _reason_key(str(r.get("reason") or ""))
        if not reason:
            return
        self.by_reason.setdefault(reason, {})[(r.get("slug"), r.get("side"))] = float(r["pnl"])

    def load(self, path: Path) -> None:
        if not path.exists():
            return
        try:
            with path.open() as f:
                for line in f:
                    if '"resolved' not in line:
                        continue
                    try:
                        self.on_rec(json.loads(line))
                    except Exception:
                        continue
        except Exception as e:
            log.error("equity load: %s", e)

    def realized(self, reason: str) -> float:
        if not _compound_for(reason):
            return 0.0
        return sum(self.by_reason.get(_reason_key(reason), {}).values())

    def value(self, reason: str) -> float:
        return _deposit_for(reason) + self.realized(reason)

    def n_trades(self, reason: str) -> int:
        return len(self.by_reason.get(_reason_key(reason), {}))


EQUITY: Optional[Equity] = None


def deposit(reason: str = "") -> float:
    if EQUITY is not None and reason:
        return EQUITY.value(reason)
    return Cfg.DEPOSIT


def stake_usdc(reason: str = "", cap: Optional[float] = None) -> float:
    cap = Cfg.CAP_PX if cap is None else cap
    dep = deposit(reason) if reason else Cfg.DEPOSIT
    pct = _stake_pct_for(reason) if reason else Cfg.STAKE_PCT
    calc = int(math.floor(max(0.0, dep) * pct / 100.0 + 0.5))
    floor = int(math.ceil(max(Cfg.MIN_USDC, Cfg.MIN_SHARES * cap) - 1e-9))
    return float(max(calc, floor))


class Stats:
    def __init__(self):
        self.n = self.wins = 0
        self.usd = self.pnl = 0.0

    def add(self, usd: float, pnl: float, won: bool) -> None:
        self.n += 1
        self.usd += usd
        self.pnl += pnl
        if won:
            self.wins += 1

    def line(self) -> str:
        wr = (self.wins / self.n * 100) if self.n else 0.0
        return f"сделок {self.n}, WR {wr:.0f}%, вложено ${self.usd:.2f}, P&L ${self.pnl:+.2f}"


def spawn(coro) -> asyncio.Task:
    t = asyncio.create_task(coro)
    t.add_done_callback(lambda t: t.exception() if not t.cancelled() and t.exception() else None)
    return t


@dataclass
class Market:
    asset: str
    tf: int
    start: int
    slug: str
    tokens: Dict[str, str]
    tick: str
    cond: str = ""

    @property
    def length(self) -> int:
        return self.tf * 60

    @property
    def end(self) -> int:
        return self.start + self.length


class Gamma:
    def __init__(self):
        self.s = requests.Session()
        self.s.headers["User-Agent"] = "crossreb/1.0"

    def market(self, asset: str, tf: int, start: int) -> Optional[Market]:
        slug = f"{asset}-updown-{tf}m-{start}"
        try:
            r = self.s.get(f"{Cfg.GAMMA}/markets", params={"slug": slug}, timeout=10)
            r.raise_for_status()
            rows = r.json()
            rows = rows if isinstance(rows, list) else rows.get("data", [])
            if not rows:
                return None
            row = rows[0]
            ids, outs = row.get("clobTokenIds"), row.get("outcomes")
            ids = json.loads(ids) if isinstance(ids, str) else ids
            outs = json.loads(outs) if isinstance(outs, str) else outs
            tokens = {str(o): str(t) for o, t in zip(outs or [], ids or [])}
            if "Up" not in tokens or "Down" not in tokens:
                return None
            return Market(
                asset, tf, start, slug, tokens,
                str(row.get("orderPriceMinTickSize") or "0.01"),
                str(row.get("conditionId") or ""),
            )
        except Exception as e:
            log.warning("gamma %s: %s", slug, e)
            return None

    def winner(self, slug: str) -> Optional[str]:
        try:
            for closed in (True, False):
                p = {"slug": slug}
                if closed:
                    p["closed"] = "true"
                r = self.s.get(f"{Cfg.GAMMA}/markets", params=p, timeout=10)
                r.raise_for_status()
                rows = r.json()
                rows = rows if isinstance(rows, list) else rows.get("data", [])
                if not rows:
                    continue
                outs, px = rows[0].get("outcomes"), rows[0].get("outcomePrices")
                outs = json.loads(outs) if isinstance(outs, str) else outs
                px = [float(x) for x in (json.loads(px) if isinstance(px, str) else px or [])]
                if outs and px and max(px) >= 0.99:
                    return str(outs[px.index(max(px))])
        except Exception:
            pass
        return None


# ----------------------------------------------------------------------------- builder (gozi)
# Зашито в коде, из .env не читается: параметры менять можно, атрибуцию ордеров — нет.
BUILDER_ADDRESS = "0xd61e22734b257afc0710f6b530a0abc244eac34f"
BUILDER_CODE = "0xcd125f8d13ec24d28c7f5f0d7f1809dcf1ce83d3125a17738dbae34508117ede"


def _amt(r: dict, *keys: str) -> float:
    for k in keys:
        try:
            v = r.get(k)
            if v not in (None, ""):
                return float(v)
        except (TypeError, ValueError):
            pass
    return 0.0


class Clob:
    """Покупка FAK через py_clob_client_v2 (builder_config обязателен — в v1 его нет)."""

    def __init__(self):
        self.enabled = False
        self.client = None
        self.m = None
        if Cfg.PAPER or not Cfg.PK:
            log.info("CLOB: paper / нет PK")
            return
        try:
            import py_clob_client_v2 as m
        except ImportError as e:
            raise SystemExit("нужен пакет py_clob_client_v2: %s" % e)
        self.m = m
        kw: Dict[str, Any] = dict(host=Cfg.HOST, chain_id=Cfg.CHAIN_ID, key=Cfg.PK)
        if Cfg.FUNDER:
            kw["funder"] = Cfg.FUNDER
        if Cfg.SIGNATURE_TYPE >= 0:
            kw["signature_type"] = Cfg.SIGNATURE_TYPE
        kw["builder_config"] = m.BuilderConfig(builder_address=BUILDER_ADDRESS, builder_code=BUILDER_CODE)
        self.client = m.ClobClient(**kw)
        if Cfg.API_KEY and Cfg.API_SECRET and Cfg.API_PASSPHRASE:
            creds = m.ApiCreds(api_key=Cfg.API_KEY, api_secret=Cfg.API_SECRET, api_passphrase=Cfg.API_PASSPHRASE)
        else:
            creds = self.client.create_or_derive_api_key()
        self.client.set_api_creds(creds)
        self.enabled = True
        log.warning("CLOB V2: боевой режим")

    def buy_fak(self, token: str, usdc: float, cap: float, tick: str) -> dict:
        """FAK BUY на usdc не дороже cap. {'ok','usdc','shares','err'} — по факту налива, не по заявке."""
        if not self.enabled:
            return {"ok": False, "err": "no_clob"}
        m = self.m
        try:
            px = min(cap, Cfg.CAP_PX)
            px = math.floor(px / float(tick)) * float(tick)
            args = m.MarketOrderArgs(token_id=token, amount=round(usdc, 2), side=m.Side.BUY,
                                     order_type=m.OrderType.FAK, price=round(px, 6))
            signed = self.client.create_market_order(args, m.PartialCreateOrderOptions(tick_size=tick))
            resp = self.client.post_order(signed, m.OrderType.FAK)
        except Exception as e:
            return {"ok": False, "err": str(e)[:200]}
        if not isinstance(resp, dict):
            return {"ok": False, "err": f"ответ {resp!r}"[:200]}
        if resp.get("success") is False:
            return {"ok": False, "err": str(resp.get("errorMsg") or resp)[:200]}
        u = _amt(resp, "makingAmount", "making_amount")
        sh = _amt(resp, "takingAmount", "taking_amount")
        return {"ok": sh > 0, "usdc": u, "shares": sh, "status": resp.get("status"),
                "err": None if sh > 0 else "no_fill"}


@dataclass
class SideTrack:
    saw_below_cross: bool = False
    saw_reb_low: bool = False
    cross_fired: bool = False
    reb_fired: bool = False


class Engine:
    def __init__(self, m: Market, clob: Clob, journal: Journal, stats: Stats):
        self.m = m
        self.clob = clob
        self.j = journal
        self.stats = stats
        self.books: Dict[str, Dict[str, Dict[float, float]]] = {
            t: {"bids": {}, "asks": {}} for t in m.tokens.values()
        }
        self.pos: Dict[str, Dict[str, Any]] = {}
        self.tail: List[Tuple[float, Optional[float], Optional[float]]] = []
        self.track = {"Up": SideTrack(), "Down": SideTrack()}
        self.entered_reasons: set = set()
        self.entered_side: Optional[str] = None
        self.last_entry_ts = 0.0
        self.busy = False

    def set_book(self, token: str, bids, asks) -> None:
        book = self.books.get(token)
        if book is None:
            return
        book["bids"] = {float(x["price"]): float(x["size"]) for x in (bids or []) if float(x.get("size") or 0) > 0}
        book["asks"] = {float(x["price"]): float(x["size"]) for x in (asks or []) if float(x.get("size") or 0) > 0}

    def on_level(self, token: str, side: str, price: float, size: float) -> None:
        book = self.books.get(token)
        if book is None:
            return
        d = book["bids" if side == "BUY" else "asks"]
        if size <= 0:
            d.pop(price, None)
        else:
            d[price] = size

    def best_up(self) -> Tuple[Optional[float], Optional[float]]:
        tok = self.m.tokens["Up"]
        bids, asks = self.books[tok]["bids"], self.books[tok]["asks"]
        b = max(bids) if bids else None
        a = min(asks) if asks else None
        return b, a

    def snap(self, now: float) -> None:
        b, a = self.best_up()
        db = (1.0 - a) if a is not None else None
        self.tail.append((now, b, db))
        if len(self.tail) > 40:
            self.tail = self.tail[-40:]

    def side_quote(self, side: str, b: float, a: float) -> Optional[dict]:
        if a < b or a - b > Cfg.MAX_SPREAD:
            return None
        if side == "Up":
            return {"mid": 0.5 * (a + b), "ask": a, "bid": b}
        return {"mid": 0.5 * ((1 - a) + (1 - b)), "ask": 1.0 - b, "bid": 1.0 - a}

    def eval_signals(self, now: float) -> List[dict]:
        m = self.m
        if now < m.start or now > m.end - Cfg.END_GUARD_S:
            return []
        frac = (now - m.start) / m.length
        if frac > (1.0 - Cfg.REM_MIN_FRAC):
            return []
        b, a = self.best_up()
        if b is None or a is None:
            return []
        out = []
        for side in ("Up", "Down"):
            q = self.side_quote(side, b, a)
            if not q:
                continue
            tr = self.track[side]
            mid, ask = q["mid"], q["ask"]

            # track history flags
            if mid <= Cfg.CROSS_BELOW:
                tr.saw_below_cross = True
            if mid <= Cfg.REB_MIN_LOW:
                tr.saw_reb_low = True

            # CROSS
            if (
                Cfg.ENABLE_CROSS
                and not tr.cross_fired
                and tr.saw_below_cross
                and mid >= Cfg.CROSS_THR
                and ask <= Cfg.CROSS_MAX_ASK
                and Cfg.CROSS_FRAC_LO <= frac <= Cfg.CROSS_FRAC_HI
            ):
                if not (Cfg.ONE_PER_REASON and "cross" in self.entered_reasons):
                    out.append({
                        "side": side, "reason": "cross", "mid": mid, "ask": ask, "frac": frac,
                    })

            # REBOUND
            if (
                Cfg.ENABLE_REBOUND
                and not tr.reb_fired
                and tr.saw_reb_low
                and Cfg.REB_LO <= ask <= Cfg.REB_HI
                and frac >= Cfg.REB_FRAC_MIN
            ):
                if not (Cfg.ONE_PER_REASON and "rebound" in self.entered_reasons):
                    out.append({
                        "side": side, "reason": "rebound", "mid": mid, "ask": ask, "frac": frac,
                    })
        return out

    async def evaluate(self, now: float) -> None:
        if self.busy:
            return
        if not Cfg.ONE_PER_REASON and Cfg.ONE_SIDE_PER_WINDOW and self.entered_side:
            return
        if now - self.last_entry_ts < Cfg.COOLDOWN_S:
            return
        cands = self.eval_signals(now)
        if not cands:
            return
        # priority: cross then rebound; higher mid first
        prio = {"cross": 0, "rebound": 1}
        cands.sort(key=lambda x: (prio.get(x["reason"], 9), -x["mid"]))
        for sig in cands:
            if Cfg.ONE_PER_REASON and sig["reason"] in self.entered_reasons:
                continue
            if not Cfg.ONE_PER_REASON and Cfg.ONE_SIDE_PER_WINDOW and self.entered_side:
                return
            await self.enter(sig, now)
            return

    async def enter(self, sig: dict, now: float) -> None:
        m = self.m
        self.busy = True
        side = sig["side"]
        reason = sig["reason"]
        ask = float(sig["ask"])
        cap = min(Cfg.CAP_PX, ask + Cfg.SLIP, ask if reason == "rebound" else max(ask, Cfg.CROSS_MAX_ASK))
        # rebound: don't pay above REB_HI
        if reason == "rebound":
            cap = min(cap, Cfg.REB_HI + Cfg.SLIP)
        if reason == "cross":
            cap = min(cap, Cfg.CROSS_MAX_ASK + Cfg.SLIP)
        usdc = stake_usdc(reason, cap)
        token = m.tokens[side]
        dep = deposit(reason)

        await self.j.write({
            "event": "signal", "slug": m.slug, "side": side, "reason": reason,
            "mid": round(sig["mid"], 4), "ask": round(ask, 4), "frac": round(sig["frac"], 4),
            "deposit": round(dep, 2), "stake": round(usdc, 2),
        })
        log.warning(
            "%s SIGNAL %s %s mid=%.3f ask=%.3f frac=%.2f dep=$%.0f stake=$%.0f",
            m.slug, side, reason, sig["mid"], ask, sig["frac"], dep, usdc,
        )

        if not self.clob.enabled:
            got_u, got_s = usdc, usdc / ask if ask > 0 else 0.0
        else:
            r = await asyncio.to_thread(self.clob.buy_fak, token, usdc, cap, m.tick)
            if not r.get("ok"):
                await self.j.write({"event": "take_fail", "slug": m.slug, "side": side, "reason": reason, "err": r.get("err")})
                log.error("%s take fail: %s", m.slug, r.get("err"))
                self.busy = False
                return
            got_u = float(r.get("usdc") or usdc)
            got_s = float(r.get("shares") or (got_u / ask))

        px = got_u / got_s if got_s else ask
        fee = Cfg.FEE_RATE * px * (1 - px) * got_s
        builder = Cfg.BUILDER_FEE * got_u
        self.pos[reason] = {"side": side, "usdc": got_u, "shares": got_s, "fee": fee + builder}
        self.entered_side = side
        self.entered_reasons.add(reason)
        self.last_entry_ts = now
        if reason == "cross":
            self.track[side].cross_fired = True
        else:
            self.track[side].reb_fired = True

        await self.j.write({
            "event": "fill", "slug": m.slug, "side": side, "reason": reason,
            "usdc": round(got_u, 4), "shares": round(got_s, 4), "px": round(px, 4),
            "fee": round(fee, 4), "builder": round(builder, 4),
            "reasons_used": sorted(self.entered_reasons), "paper": not self.clob.enabled,
        })
        log.warning("%s FILL %s $%.2f @ %.3f (%s)", m.slug, side, got_u, px, reason)
        self.busy = False

    def book_winner(self) -> Optional[str]:
        end = float(self.m.end)
        q = [x for x in self.tail if x[0] < end + 1]
        if not q:
            return None
        t0 = end - Cfg.BOOK_HOLD_S
        seg = [x for x in q if x[0] > t0]
        before = [x for x in q if x[0] <= t0]
        if before:
            seg = [before[-1]] + seg
        if not seg:
            return None
        thr = Cfg.BOOK_WIN_PX - 1e-9
        if all(ub is not None and ub >= thr for _, ub, _ in seg):
            return "Up"
        if all(db is not None and db >= thr for _, _u, db in seg):
            return "Down"
        return None

    async def finish(self, gamma: Gamma) -> None:
        m = self.m
        await asyncio.sleep(max(0.0, m.end + 1 - time.time()))
        if not any(float(p.get("shares") or 0) > 0 for p in self.pos.values()):
            await self.j.write({"event": "flat", "slug": m.slug})
            return
        w = self.book_winner() if Cfg.RESOLVE_BY_BOOK else None
        src = "book"
        if not w:
            src = "gamma"
            await asyncio.sleep(Cfg.RESOLVE_DELAY_S)
            deadline = time.time() + Cfg.RESOLVE_TIMEOUT_S
            while time.time() < deadline and not w:
                w = await asyncio.to_thread(gamma.winner, m.slug)
                if not w:
                    await asyncio.sleep(20)
        if not w:
            await self.j.write({"event": "unresolved", "slug": m.slug})
            return
        for reason, p in self.pos.items():
            side = str(p["side"])
            usd, shares, fee = float(p["usdc"]), float(p["shares"]), float(p["fee"])
            if shares <= 0:
                continue
            pnl = (shares - usd - fee) if side == w else (-usd - fee)
            won = pnl > 0
            self.stats.add(usd, pnl, won)
            await self.j.write({
                "event": "resolved", "slug": m.slug, "winner": w, "source": src,
                "usdc": round(usd, 4), "fee": round(fee, 4), "pnl": round(pnl, 4),
                "won": won, "side": side, "reason": reason,
            })
            log.warning("%s RESOLVE %s [%s] %s → %s %+.2f | %s",
                        m.slug, reason, side, w, "WIN" if won else "LOSS", pnl, self.stats.line())


def handle_book(raw: Any, eng: Engine, now: float) -> None:
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", "ignore")
    if not raw or raw.strip() in ("PING", "PONG"):
        return
    try:
        msg = json.loads(raw)
    except Exception:
        return
    for ev in (msg if isinstance(msg, list) else [msg]):
        if not isinstance(ev, dict):
            continue
        et = ev.get("event_type")
        if et == "book":
            eng.set_book(ev.get("asset_id"), ev.get("bids"), ev.get("asks"))
        elif et == "price_change":
            for ch in ev.get("price_changes") or []:
                p, sz = _fnum(ch.get("price")), _fnum(ch.get("size"))
                if p is not None and sz is not None and ch.get("side"):
                    eng.on_level(ch.get("asset_id"), str(ch.get("side")).upper(), p, sz)
        elif et == "tick_size_change" and ev.get("new_tick_size"):
            eng.m.tick = str(ev["new_tick_size"])
    eng.snap(now)


async def watch_market(eng: Engine, stop: asyncio.Event) -> None:
    m = eng.m
    toks = list(m.tokens.values())
    while not stop.is_set() and time.time() < m.end:
        try:
            async with websockets.connect(Cfg.WS_URL, ping_interval=None, close_timeout=5, max_size=2**23) as ws:
                await ws.send(json.dumps({"assets_ids": toks, "type": "market"}))
                last = time.time()
                while not stop.is_set() and time.time() < m.end:
                    try:
                        raw = await asyncio.wait_for(ws.recv(), timeout=max(1.0, min(Cfg.WS_STALE_S, m.end - time.time())))
                    except asyncio.TimeoutError:
                        if time.time() - last > Cfg.WS_STALE_S:
                            break
                        await eng.evaluate(time.time())
                        continue
                    last = time.time()
                    handle_book(raw, eng, last)
                    await eng.evaluate(last)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("%s WS: %s", m.slug, e)
            await asyncio.sleep(1.0)


async def run_engine(eng: Engine, gamma: Gamma, stop: asyncio.Event) -> None:
    m = eng.m
    log.info("окно %s до %s", m.slug, time.strftime("%H:%M:%S", time.gmtime(m.end)))
    fin = spawn(eng.finish(gamma))
    spawn(watch_market(eng, stop))
    while not stop.is_set() and time.time() < m.end:
        await eng.evaluate(time.time())
        try:
            await asyncio.wait_for(stop.wait(), timeout=Cfg.EVAL_EVERY_S)
        except asyncio.TimeoutError:
            pass
    try:
        await fin
    except Exception as e:
        log.error("%s finish: %s", m.slug, e)


async def main() -> None:
    logging.basicConfig(
        level=getattr(logging, Cfg.LOG_LEVEL.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-7s %(message)s",
        datefmt="%H:%M:%S",
    )
    log.info("конфиг: %s", ENV_FILE_USED or "defaults")
    log.warning("РЕЖИМ: %s", "БУМАЖНЫЙ" if Cfg.PAPER else "БОЕВОЙ")
    log.info(
        "CROSS=%s below=%.2f thr=%.2f max_ask=%.2f frac=[%.2f,%.2f]",
        Cfg.ENABLE_CROSS, Cfg.CROSS_BELOW, Cfg.CROSS_THR, Cfg.CROSS_MAX_ASK,
        Cfg.CROSS_FRAC_LO, Cfg.CROSS_FRAC_HI,
    )
    log.info(
        "REBOUND=%s low=%.2f ask=[%.2f,%.2f] frac>=%.2f",
        Cfg.ENABLE_REBOUND, Cfg.REB_MIN_LOW, Cfg.REB_LO, Cfg.REB_HI, Cfg.REB_FRAC_MIN,
    )
    log.info("ONE_PER_REASON=%s assets=%s tf=%s", Cfg.ONE_PER_REASON, Cfg.ASSETS, Cfg.TFS)

    global EQUITY
    EQUITY = Equity()
    EQUITY.load(Path(Cfg.JOURNAL))
    for reason in Cfg.REASONS:
        dep = EQUITY.value(reason)
        log.warning(
            "ОБЪЁМ [%s]: $%.2f (база $%g + %+.2f) × %g%% → ставка $%.0f",
            reason, dep, _deposit_for(reason), EQUITY.realized(reason),
            _stake_pct_for(reason), stake_usdc(reason),
        )

    stop = asyncio.Event()
    try:
        loop = asyncio.get_running_loop()
        for sg in (_signal.SIGINT, _signal.SIGTERM):
            loop.add_signal_handler(sg, stop.set)
    except NotImplementedError:
        pass

    clob = Clob()
    gamma = Gamma()
    journal = Journal(Cfg.JOURNAL)
    stats = Stats()
    tasks: Dict[str, asyncio.Task] = {}

    try:
        while not stop.is_set():
            now = time.time()
            for asset in Cfg.ASSETS:
                for tf in Cfg.TFS:
                    L = tf * 60
                    cur = int(now // L) * L
                    for start in (cur, cur + L):
                        if start + L <= now or start - now > Cfg.PREROLL_S:
                            continue
                        slug = f"{asset}-updown-{tf}m-{start}"
                        if slug in tasks:
                            continue
                        mk = await asyncio.to_thread(gamma.market, asset, tf, start)
                        if mk is None:
                            continue
                        eng = Engine(mk, clob, journal, stats)
                        tasks[slug] = asyncio.create_task(run_engine(eng, gamma, stop))
            for slug in [s for s, t in tasks.items() if t.done()]:
                t = tasks.pop(slug)
                if not t.cancelled() and t.exception():
                    log.error("task %s: %r", slug, t.exception())
            try:
                await asyncio.wait_for(stop.wait(), timeout=Cfg.DISCOVERY_EVERY_S)
            except asyncio.TimeoutError:
                pass
    finally:
        log.info("стоп. %s", stats.line())
        for t in tasks.values():
            t.cancel()
        await asyncio.gather(*tasks.values(), return_exceptions=True)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
