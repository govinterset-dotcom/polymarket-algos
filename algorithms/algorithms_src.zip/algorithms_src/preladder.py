#!/usr/bin/env python3
"""
preladder.py — предсетка лимиток на ОБА исхода + тейкер на противоположный исход на каждый филл (Polymarket BTC up/down 5m/15m).

Ядро (без фильтров, без сигналов):
  1. За LEAD_5 (300 с) до старта 5m окна и за LEAD_15 (900 с) до старта 15m окна бот ставит GTD BUY лимитки
     на Up и на Down по уровням LEVELS (0.45 … 0.10), LIMIT_USDC $ на каждый уровень. Дальше лимитки не трогает:
     они сами истекают (GTD = конец окна + GTD_PAD_S).
  2. Рынок ведётся с момента постановки сетки (книга до старта может быть широкой) — на каждый таймфрейм
     одновременно живут несколько окон (текущее + ближайшие по LEAD).
  3. На КАЖДЫЙ филл лимитки (даже частичный) бот покупает ТЕЙКЕРОМ противоположный исход:
       TAKER_MODE=usdc   → сумма тейкера = залитые USDC лимитки × TAKER_MULT   (10$ → 35$ при 3.5)
       TAKER_MODE=shares → столько же долей, сколько налилось лимиткой
     Набирает всю сумму через серию FAK (повтор, пока не набрал или не вышел таймаут).
  4. Первая попытка тейкера — ПРЕДПОДПИСАННЫЙ ордер (подписан при постановке сетки, уходит сразу при полном филле);
     добор и частичные филлы подписываются на лету.
  5. Фиксируем филлы по user-WS (order events, size_matched) + сверка get_order.
Исход окна — по книге (как в premove_live), gamma — запасной. P&L по рынку пишется в журнал.
Конфиг: preladder.env рядом со скриптом (или ENV_FILE). PAPER=true по умолчанию.
Нужны: requests, websockets; для боя — py_clob_client_v2.
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests
import websockets

ENV_FILE_USED = ""


def _load_env_file() -> None:
    global ENV_FILE_USED
    explicit = os.environ.get("ENV_FILE", "").strip()
    here = Path(sys.argv[0]).resolve().parent if sys.argv and sys.argv[0] else Path.cwd()
    stem = Path(sys.argv[0]).stem if sys.argv and sys.argv[0] else "preladder"
    cands = [Path(explicit)] if explicit else [here / f"{stem}.env", here / ".env",
                                               Path.cwd() / f"{stem}.env", Path.cwd() / ".env"]
    for p in cands:
        try:
            if not p.is_file():
                continue
        except OSError:
            continue
        for raw in p.read_text().splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            if line.lower().startswith("export "):
                line = line[7:].strip()
            k, v = line.split("=", 1)
            k, v = k.strip(), v.strip()
            if v[:1] in ("'", '"') and v[-1:] == v[:1] and len(v) >= 2:
                v = v[1:-1]
            else:
                cut = v.find(" #")
                if cut >= 0:
                    v = v[:cut].rstrip()
                if v.startswith("#"):
                    v = ""
            os.environ[k] = v
        ENV_FILE_USED = str(p)
        return
    if explicit:
        raise SystemExit(f"ENV_FILE={explicit} не найден")


_load_env_file()


def _env(k: str, d: str = "") -> str:
    return os.environ.get(k, d).strip()


def _f(k: str, d: float) -> float:
    v = _env(k)
    return float(v) if v else d


def _i(k: str, d: int) -> int:
    v = _env(k)
    return int(float(v)) if v else d


def _b(k: str, d: bool) -> bool:
    v = _env(k).lower()
    return d if not v else v in ("1", "true", "yes", "on")


def _list_f(k: str, d: str) -> List[float]:
    return [float(x) for x in _env(k, d).replace(" ", "").split(",") if x]


class Cfg:
    PAPER = _b("PAPER", True)
    PK = _env("PK")
    FUNDER = _env("FUNDER")
    SIGNATURE_TYPE = _i("SIGNATURE_TYPE", -1)
    API_KEY = _env("CLOB_API_KEY")
    API_SECRET = _env("CLOB_API_SECRET")
    API_PASSPHRASE = _env("CLOB_API_PASSPHRASE")
    HOST = _env("CLOB_HOST", "https://clob.polymarket.com")
    CHAIN_ID = _i("CHAIN_ID", 137)
    GAMMA = _env("GAMMA_HOST", "https://gamma-api.polymarket.com")
    WS_URL = _env("WS_URL", "wss://ws-subscriptions-clob.polymarket.com/ws/market")
    WS_USER_URL = _env("WS_USER_URL", "wss://ws-subscriptions-clob.polymarket.com/ws/user")

    ASSETS = [a.strip().lower() for a in _env("ASSETS", "btc").split(",") if a.strip()]
    TFS = [int(x) for x in _env("TFS", "5,15").replace(" ", "").split(",") if x]
    LEAD_5 = _f("LEAD_5", 300.0)              # ставим сетку за N с до старта 5m окна
    LEAD_15 = _f("LEAD_15", 900.0)            # ... и 15m окна (больше = раньше и на несколько окон вперёд)
    MIN_PLACE_LEAD_S = _f("MIN_PLACE_LEAD_S", 5.0)   # меньше N с до старта — не ставим
    PLACE_IF_STARTED = _b("PLACE_IF_STARTED", False)

    # сетка
    LEVELS = _list_f("LEVELS", "0.45,0.40,0.35,0.30,0.25,0.20,0.15,0.10")
    LIMIT_USDC = _f("LIMIT_USDC", 10.0)       # $ на каждый уровень, каждый исход
    MIN_SHARES = _f("MIN_SHARES", 5.0)
    MIN_USDC = _f("MIN_USDC", 1.0)
    GTD_PAD_S = _i("GTD_PAD_S", 30)           # срок GTD = конец окна + pad
    GTD_MIN_S = _i("GTD_MIN_S", 200)          # биржа: срок GTD >= 180 с от «сейчас»

    # тейкер
    TAKER_MODE = _env("TAKER_MODE", "usdc").lower()    # usdc | shares
    TAKER_MULT = _f("TAKER_MULT", 3.5)        # для usdc: сумма тейкера = залитые $ лимитки × MULT
    TAKER_SLIP = _f("TAKER_SLIP", 0.05)       # потолок FAK = 1 − цена_лимитки + SLIP (но не выше CAP_PX)
    CAP_PX = _f("CAP_PX", 0.97)
    MIN_TAKER_USDC = _f("MIN_TAKER_USDC", 1.0)  # меньше — копим (частичные филлы), биржа: BUY >= $1
    TAKER_TIMEOUT_S = _f("TAKER_TIMEOUT_S", 20.0)
    TAKER_MAX_TRIES = _i("TAKER_MAX_TRIES", 30)
    RETRY_S = _f("RETRY_S", 0.25)
    END_GUARD_S = _f("END_GUARD_S", 2.0)
    FEE_RATE = _f("FEE_RATE", 0.07)           # комиссия тейкера: rate × p × (1−p) на долю
    PRESIGN = _b("PRESIGN", True)

    # фиксация филлов / исход
    RECON_S = _f("RECON_S", 20.0)             # сверка get_order по сетке (страховка к user-WS)
    PAPER_POLL_S = _f("PAPER_POLL_S", 0.2)
    RESOLVE_BY_BOOK = _b("RESOLVE_BY_BOOK", True)
    BOOK_WIN_PX = _f("BOOK_WIN_PX", 0.99)
    BOOK_HOLD_S = _f("BOOK_HOLD_S", 3.0)
    RESOLVE_DELAY_S = _f("RESOLVE_DELAY_S", 60.0)
    RESOLVE_TIMEOUT_S = _f("RESOLVE_TIMEOUT_S", 8 * 3600.0)
    WS_STALE_S = _f("WS_STALE_S", 30.0)
    JOURNAL = _env("JOURNAL", "preladder.jsonl")
    LOG_LEVEL = _env("LOG_LEVEL", "INFO")


log = logging.getLogger("preladder")


def _num(d: dict, *keys) -> Optional[float]:
    for k in keys:
        v = d.get(k)
        if v not in (None, ""):
            try:
                return float(v)
            except (TypeError, ValueError):
                pass
    return None


def _fnum(v) -> Optional[float]:
    try:
        return None if v in (None, "") else float(v)
    except (TypeError, ValueError):
        return None


def lead_for(tf: int) -> float:
    return Cfg.LEAD_5 if tf == 5 else Cfg.LEAD_15 if tf == 15 else float(tf * 60)


def book_winner_tail(tail, end: float) -> Optional[str]:
    """tail: (t, бид Up, бид Down). Исход, если на [конец − BOOK_HOLD_S, конец] бид победителя >= BOOK_WIN_PX."""
    q = [x for x in tail if x[0] < end + 1.0]
    if not q or end - q[-1][0] > 20:
        return None
    t0 = end - Cfg.BOOK_HOLD_S
    seg = [x for x in q if x[0] > t0]
    before = [x for x in q if x[0] <= t0]
    if before:
        seg = [before[-1]] + seg
    if not seg:
        return None
    thr = Cfg.BOOK_WIN_PX - 1e-9
    if all(ub is not None and ub >= thr for _, ub, _d in seg):
        return "Up"
    if all(db is not None and db >= thr for _, _u, db in seg):
        return "Down"
    return None


class Journal:
    def __init__(self, path: str):
        self.path = Path(path)
        self.lock = asyncio.Lock()

    async def write(self, rec: dict) -> None:
        rec = {"ts": round(time.time(), 3), **rec}
        line = json.dumps(rec, ensure_ascii=False, default=str)
        async with self.lock:
            await asyncio.to_thread(self._append, line)

    def _append(self, line: str) -> None:
        with self.path.open("a") as f:
            f.write(line + "\n")


def spawn(coro) -> asyncio.Task:
    t = asyncio.create_task(coro)
    t.add_done_callback(_done)
    return t


def _done(t: asyncio.Task) -> None:
    if not t.cancelled() and t.exception():
        log.error("фоновая задача упала: %r", t.exception())


# ════════════════════════════════════════════════════════════════ рынки (gamma)
@dataclass
class Market:
    asset: str
    tf: int
    start: int
    slug: str
    tokens: Dict[str, str]
    tick: str
    cond: str = ""

    @property
    def length(self) -> int:
        return self.tf * 60

    @property
    def end(self) -> int:
        return self.start + self.length


class Gamma:
    def __init__(self):
        self.s = requests.Session()
        self.s.headers["User-Agent"] = "preladder/1.0"

    def _rows(self, slug: str, closed: bool = False) -> list:
        p = {"slug": slug}
        if closed:
            p["closed"] = "true"
        r = self.s.get(f"{Cfg.GAMMA}/markets", params=p, timeout=10)
        r.raise_for_status()
        d = r.json()
        return d if isinstance(d, list) else d.get("data", [])

    def market(self, asset: str, tf: int, start: int) -> Optional[Market]:
        slug = f"{asset}-updown-{tf}m-{start}"
        try:
            rows = self._rows(slug)
            if not rows:
                return None
            row = rows[0]
            ids, outs = row.get("clobTokenIds"), row.get("outcomes")
            ids = json.loads(ids) if isinstance(ids, str) else ids
            outs = json.loads(outs) if isinstance(outs, str) else outs
            tokens = {str(o): str(t) for o, t in zip(outs or [], ids or [])}
            if "Up" not in tokens or "Down" not in tokens:
                return None
            return Market(asset, tf, start, slug, tokens, str(row.get("orderPriceMinTickSize") or "0.01"),
                          str(row.get("conditionId") or ""))
        except Exception as e:
            log.warning("gamma %s: %s", slug, e)
            return None

    def winner(self, slug: str) -> Optional[str]:
        try:
            rows = self._rows(slug, closed=True) or self._rows(slug)
            if not rows:
                return None
            outs, px = rows[0].get("outcomes"), rows[0].get("outcomePrices")
            outs = json.loads(outs) if isinstance(outs, str) else outs
            px = [float(x) for x in (json.loads(px) if isinstance(px, str) else px or [])]
            if not outs or not px or max(px) < 0.99:
                return None
            return str(outs[px.index(max(px))])
        except Exception as e:
            log.debug("резолв %s: %s", slug, e)
            return None


async def _pinger(ws, stop: asyncio.Event, every: float, until: float = 1e18) -> None:
    try:
        while not stop.is_set() and time.time() < until:
            await asyncio.sleep(every)
            await ws.send("PING")
    except Exception:
        pass


# ════════════════════════════════════════════════════════════════ CLOB
# Зашито в коде, из .env не читается (как в остальных ботах).
BUILDER_ADDRESS = "0xd61e22734b257afc0710f6b530a0abc244eac34f"
BUILDER_CODE = "0xcd125f8d13ec24d28c7f5f0d7f1809dcf1ce83d3125a17738dbae34508117ede"


class Clob:
    """GTD BUY лимитки, предподписанные/обычные FAK BUY через py_clob_client_v2."""

    def __init__(self):
        self.enabled = not Cfg.PAPER
        self.client = None
        self.m = None
        self.creds = None
        if not self.enabled:
            return
        try:
            import py_clob_client_v2 as m
        except ImportError as e:
            raise SystemExit("нужен пакет py_clob_client_v2: %s" % e)
        if not Cfg.PK:
            raise SystemExit("PK не задан, а PAPER=false")
        self.m = m
        kw: Dict[str, Any] = dict(host=Cfg.HOST, chain_id=Cfg.CHAIN_ID, key=Cfg.PK)
        if Cfg.FUNDER:
            kw["funder"] = Cfg.FUNDER
        if Cfg.SIGNATURE_TYPE >= 0:
            kw["signature_type"] = Cfg.SIGNATURE_TYPE
        kw["builder_config"] = m.BuilderConfig(builder_address=BUILDER_ADDRESS, builder_code=BUILDER_CODE)
        self.client = m.ClobClient(**kw)
        if Cfg.API_KEY and Cfg.API_SECRET and Cfg.API_PASSPHRASE:
            creds = m.ApiCreds(api_key=Cfg.API_KEY, api_secret=Cfg.API_SECRET, api_passphrase=Cfg.API_PASSPHRASE)
        else:
            creds = self.client.create_or_derive_api_key()
        self.client.set_api_creds(creds)
        self.creds = creds
        log.info("CLOB подключён — БОЕВОЙ режим")

    # --- лимитка
    def place(self, token: str, price: float, shares: float, tick: str, expiration: int) -> dict:
        m = self.m
        try:
            args = m.OrderArgsV2(token_id=token, price=round(price, 6), size=round(shares, 2),
                                 side=m.Side.BUY, expiration=int(expiration))
            signed = self.client.create_order(args, m.PartialCreateOrderOptions(tick_size=tick))
        except Exception as e:
            return {"ok": False, "unknown": False, "err": f"сборка: {e}"[:200]}
        try:
            r = self.client.post_order(signed, m.OrderType.GTD)
        except Exception as e:
            code = getattr(e, "status_code", None)
            return {"ok": False, "unknown": not (isinstance(code, int) and 400 <= code < 500), "err": str(e)[:200]}
        if not isinstance(r, dict):
            return {"ok": False, "unknown": True, "err": f"ответ {r!r}"[:200]}
        oid = r.get("orderID") or r.get("orderId") or r.get("id")
        if r.get("success") is False or not oid:
            return {"ok": False, "unknown": False, "err": str(r.get("errorMsg") or r)[:200]}
        return {"ok": True, "id": oid, "status": r.get("status"), "unknown": False}

    def order(self, oid: str) -> Optional[dict]:
        try:
            r = self.client.get_order(oid)
            return r if isinstance(r, dict) else None
        except Exception as e:
            log.warning("ордер %s: %s", oid[:12], e)
            return None

    # --- тейкер FAK
    def sign(self, token: str, usdc: float, cap: float, tick: str) -> Any:
        m = self.m
        args = m.MarketOrderArgs(token_id=token, amount=round(usdc, 2), side=m.Side.BUY,
                                 order_type=m.OrderType.FAK, price=round(cap, 6))
        return self.client.create_market_order(args, m.PartialCreateOrderOptions(tick_size=tick))

    def post(self, signed: Any) -> dict:
        m = self.m
        try:
            r = self.client.post_order(signed, m.OrderType.FAK)
        except Exception as e:
            code = getattr(e, "status_code", None)
            return {"ok": False, "unknown": not (isinstance(code, int) and 400 <= code < 500), "err": str(e)[:200]}
        if not isinstance(r, dict):
            return {"ok": False, "unknown": True, "err": f"ответ {r!r}"[:200]}
        if r.get("success") is False:
            return {"ok": False, "unknown": False, "err": str(r.get("errorMsg") or r)[:200]}
        u = _num(r, "makingAmount", "making_amount") or 0.0
        sh = _num(r, "takingAmount", "taking_amount") or 0.0
        return {"ok": sh > 0, "usdc": u, "shares": sh, "status": r.get("status"), "unknown": False,
                "id": r.get("orderID") or r.get("orderId")}

    def buy(self, token: str, usdc: float, cap: float, tick: str) -> dict:
        try:
            signed = self.sign(token, usdc, cap, tick)
        except Exception as e:
            return {"ok": False, "unknown": False, "err": f"сборка: {e}"[:200]}
        return self.post(signed)


# ════════════════════════════════════════════════════════════════ движок окна
class Engine:
    def __init__(self, m: Market, clob: Clob, j: Journal, stats: "Stats"):
        self.m, self.clob, self.j, self.stats = m, clob, j, stats
        self.pos: Dict[str, Dict[str, float]] = {s: {"usdc": 0.0, "shares": 0.0, "fee": 0.0} for s in ("Up", "Down")}
        self.levels: Dict[str, Dict[str, Dict[float, float]]] = {t: {"bids": {}, "asks": {}} for t in m.tokens.values()}
        self.tail: List[Tuple[float, Optional[float], Optional[float]]] = []
        self.orders: List[dict] = []              # вся сетка
        self.by_id: Dict[str, dict] = {}
        self.placed = False
        self.taker_tasks: List[asyncio.Task] = []
        self.last_user_ev = 0.0

    # --- книга
    def set_book(self, token: str, bids, asks) -> None:
        book = self.levels.get(token)
        if book is None:
            return
        book["bids"] = {float(x["price"]): float(x["size"]) for x in bids or [] if float(x.get("size", 0) or 0) > 0}
        book["asks"] = {float(x["price"]): float(x["size"]) for x in asks or [] if float(x.get("size", 0) or 0) > 0}

    def on_levels(self, token: str, side: str, price: float, size: float) -> None:
        book = self.levels.get(token)
        if book is None:
            return
        d = book["bids" if side == "BUY" else "asks"]
        if size <= 0:
            d.pop(price, None)
        else:
            d[price] = size

    def best_bid(self, side: str) -> Optional[float]:
        b = self.levels[self.m.tokens[side]]["bids"]
        return max(b) if b else None

    def best_ask(self, side: str) -> Optional[float]:
        a = self.levels[self.m.tokens[side]]["asks"]
        return min(a) if a else None

    def real_ask(self, side: str) -> Optional[float]:
        a = self.best_ask(side)
        if a is not None:
            return a
        opp = "Down" if side == "Up" else "Up"
        b = self.best_bid(opp)
        return round(1 - b, 4) if b is not None else None

    def snap(self, now: float) -> None:
        if not (self.m.end - 60 <= now < self.m.end + 1):
            return
        ub, db = self.best_bid("Up"), self.best_bid("Down")
        self.tail.append((now, ub, db))

    # --- сетка
    def _tickf(self) -> float:
        return float(self.m.tick)

    def _presign(self) -> None:
        """Предподписанный тейкер на полную сумму для каждого уровня (в потоке: тёплый кэш tick/neg_risk)."""
        for o in self.orders:
            if o.get("pre") is not None or not Cfg.PRESIGN:
                continue
            try:
                o["pre"] = self.clob.sign(self.m.tokens[o["opp"]], o["t_full"], o["cap"], self.m.tick)
            except Exception as e:
                log.warning("%s: предподпись %s %.2f: %s", self.m.slug, o["side"], o["px"], e)

    def build_grid(self) -> None:
        m, tick = self.m, self._tickf()
        for side in ("Up", "Down"):
            opp = "Down" if side == "Up" else "Up"
            for lv in Cfg.LEVELS:
                px = round(max(tick, math.floor(lv / tick + 1e-9) * tick), 4)
                sh = math.floor(Cfg.LIMIT_USDC / px * 100) / 100
                if sh < Cfg.MIN_SHARES or sh * px < Cfg.MIN_USDC - 1e-9:
                    sh = max(Cfg.MIN_SHARES, math.ceil(Cfg.MIN_USDC / px * 100) / 100)
                cap = round(min(Cfg.CAP_PX, 1 - px + Cfg.TAKER_SLIP), 4)
                cap = round(math.floor(cap / tick + 1e-9) * tick, 4)
                t_full = self.taker_target(px, sh)
                self.orders.append({"side": side, "opp": opp, "px": px, "shares": sh, "oid": None, "matched": 0.0,
                                    "cap": cap, "t_full": t_full, "pre": None, "pend": 0.0, "paper_t": 0.0})

    @staticmethod
    def taker_target(px: float, shares: float) -> float:
        if Cfg.TAKER_MODE == "shares":
            return round(shares * (1 - px), 2)
        return round(shares * px * Cfg.TAKER_MULT, 2)

    async def place_ladder(self) -> None:
        m = self.m
        now = time.time()
        if self.placed:
            return
        if m.start - now < Cfg.MIN_PLACE_LEAD_S and not (Cfg.PLACE_IF_STARTED and m.end - now > 30):
            await self.j.write({"event": "ladder_skip", "slug": m.slug, "reason": "too_late",
                                "to_start_s": round(m.start - now, 1)})
            log.info("%s: сетку не ставлю — до старта %.0f с", m.slug, m.start - now)
            return
        self.placed = True
        self.build_grid()
        exp = int(max(m.end + Cfg.GTD_PAD_S, now + Cfg.GTD_MIN_S))
        t0 = time.time()
        if self.clob.enabled:
            await asyncio.to_thread(self._presign)
        presign_ms = round((time.time() - t0) * 1000)
        if not self.clob.enabled:
            for o in self.orders:
                o["oid"] = f"paper-{m.slug}-{o['side']}-{o['px']}"
                self.by_id[o["oid"]] = o
                o["t_place"] = time.time()
        else:
            rs = await asyncio.gather(*[asyncio.to_thread(self.clob.place, m.tokens[o["side"]], o["px"], o["shares"],
                                                          m.tick, exp) for o in self.orders], return_exceptions=True)
            for o, r in zip(self.orders, rs):
                if isinstance(r, Exception):
                    r = {"ok": False, "unknown": True, "err": str(r)[:200]}
                o["t_place"] = time.time()
                if r.get("ok"):
                    o["oid"] = r["id"]
                    self.by_id[o["oid"]] = o
                else:
                    log.error("%s %s %.2f: лимитка не встала%s: %s", m.slug, o["side"], o["px"],
                              " (исход неизвестен!)" if r.get("unknown") else "", r.get("err"))
                await self.j.write({"event": "ladder_order", "slug": m.slug, "side": o["side"], "px": o["px"],
                                    "shares": o["shares"], "usdc": round(o["shares"] * o["px"], 4),
                                    "taker_full": o["t_full"], "expiration": exp, "paper": False,
                                    **{k: v for k, v in r.items() if k != "resp"}})
        if not self.clob.enabled:
            await self.j.write({"event": "ladder_placed", "slug": m.slug, "levels": Cfg.LEVELS, "orders": len(self.orders),
                                "paper": True, "to_start_s": round(m.start - now, 1), "expiration": exp})
        ok = sum(1 for o in self.orders if o["oid"])
        await self.j.write({"event": "ladder_done", "slug": m.slug, "placed": ok, "total": len(self.orders),
                            "to_start_s": round(m.start - now, 1), "presign_ms": presign_ms,
                            "place_ms": round((time.time() - t0) * 1000) - presign_ms, "paper": not self.clob.enabled})
        log.warning("%s: сетка %d/%d поставлена за %.0f с до старта (GTD до %s)", m.slug, ok, len(self.orders),
                    m.start - now, time.strftime("%H:%M:%S", time.gmtime(exp)))

    # --- филлы
    def on_matched(self, o: dict, matched_total: float, src: str) -> None:
        """Идемпотентно: matched_total — накопленный size_matched ордера."""
        d = matched_total - o["matched"]
        if d <= 1e-9:
            return
        o["matched"] = matched_total
        spawn(self._fill(o, d, src))

    async def _fill(self, o: dict, d_sh: float, src: str) -> None:
        m = self.m
        p = self.pos[o["side"]]
        p["usdc"] += d_sh * o["px"]
        p["shares"] += d_sh                          # лимитка (мейкер): без комиссии
        await self.j.write({"event": "limit_fill", "slug": m.slug, "side": o["side"], "px": o["px"],
                            "shares": round(d_sh, 4), "usdc": round(d_sh * o["px"], 4),
                            "matched_total": round(o["matched"], 4), "full": o["matched"] >= o["shares"] - 1e-6,
                            "src": src, "to_start_s": round(m.start - time.time(), 1)})
        log.warning("%s: ФИЛЛ лимитки %s %.2f × %.2f (%s) → тейкер %s", m.slug, o["side"], o["px"], d_sh, src, o["opp"])
        full = abs(d_sh - o["shares"]) < 1e-6
        amt = o["t_full"] if full else self.taker_target(o["px"], d_sh)
        o["pend"] += amt
        if o["pend"] + 1e-9 >= Cfg.MIN_TAKER_USDC:
            amt, o["pend"] = o["pend"], 0.0
            pre, o["pre"] = (o["pre"] if full else None), (None if full else o["pre"])
            self.taker_tasks.append(spawn(self.take(o, round(amt, 2), pre, src)))
        else:
            log.info("%s: тейкер %.2f$ копится (< %.2f$)", m.slug, o["pend"], Cfg.MIN_TAKER_USDC)

    async def take(self, o: dict, amt: float, pre: Any, src: str) -> None:
        """Набирает amt USDC противоположного исхода серией FAK (первая — предподписанная)."""
        m, opp = self.m, o["opp"]
        t0 = time.time()
        deadline = min(t0 + Cfg.TAKER_TIMEOUT_S, m.end - Cfg.END_GUARD_S)
        got_u = got_s = 0.0
        tries = 0
        paper = not self.clob.enabled
        while amt - got_u >= Cfg.MIN_TAKER_USDC - 1e-9 and time.time() < deadline and tries < Cfg.TAKER_MAX_TRIES:
            rem = round(amt - got_u, 2)
            tries += 1
            if paper:
                ask = self.real_ask(opp)
                if ask is None or ask > o["cap"] + 1e-9:
                    await asyncio.sleep(Cfg.RETRY_S)
                    continue
                r = {"ok": True, "usdc": rem, "shares": rem / ask, "paper": True}
            else:
                if tries == 1 and pre is not None:
                    r = await asyncio.to_thread(self.clob.post, pre)
                    r["presigned"] = True
                else:
                    ask = self.real_ask(opp)
                    if ask is not None and ask > o["cap"] + 1e-9:
                        await asyncio.sleep(Cfg.RETRY_S / 2)
                        continue
                    r = await asyncio.to_thread(self.clob.buy, m.tokens[opp], rem, o["cap"], m.tick)
            lat = round((time.time() - t0) * 1000)
            await self.j.write({"event": "take", "slug": m.slug, "side": opp, "for_px": o["px"], "try": tries,
                                "ask_before": self.real_ask(opp), "want": rem, "cap": o["cap"], "latency_ms": lat,
                                "src": src, **{k: v for k, v in r.items() if k != "resp"}})
            if r.get("ok"):
                u, sh = float(r["usdc"]), float(r["shares"])
                px = u / sh if sh else o["cap"]
                fee = Cfg.FEE_RATE * px * (1 - px) * sh
                p = self.pos[opp]
                p["usdc"] += u
                p["shares"] += sh
                p["fee"] += fee
                got_u += u
                got_s += sh
                continue
            if r.get("unknown"):
                log.error("%s %s: исход тейкера неизвестен (%s) — стоп, проверь вручную", m.slug, opp, r.get("err"))
                await self.j.write({"event": "take_unknown", "slug": m.slug, "side": opp, "for_px": o["px"],
                                    "want": amt, "got": round(got_u, 2), "err": r.get("err")})
                return
            await asyncio.sleep(Cfg.RETRY_S)
        short = round(amt - got_u, 2)
        ev = "take_done" if short < Cfg.MIN_TAKER_USDC - 1e-9 else "take_short"
        await self.j.write({"event": ev, "slug": m.slug, "side": opp, "for_px": o["px"], "want": amt,
                            "got_usdc": round(got_u, 4), "got_shares": round(got_s, 4),
                            "avg_px": round(got_u / got_s, 4) if got_s else None, "shortfall": short,
                            "tries": tries, "total_ms": round((time.time() - t0) * 1000)})
        (log.warning if ev == "take_done" else log.error)(
            "%s %s: тейкер %s: набрано $%.2f из $%.2f за %d попыток, %d мс", m.slug, opp,
            "ОК" if ev == "take_done" else "НЕ ДОБРАЛ", got_u, amt, tries, (time.time() - t0) * 1000)

    # --- бумага: лимитка «налилась», если аск токена опустился до цены
    async def paper_loop(self) -> None:
        m = self.m
        while time.time() < m.end:
            await asyncio.sleep(Cfg.PAPER_POLL_S)
            for o in self.orders:
                if o["matched"] >= o["shares"] - 1e-9 or not o["oid"]:
                    continue
                ask = self.best_ask(o["side"])
                if ask is not None and ask <= o["px"] + 1e-9:
                    self.on_matched(o, o["shares"], "paper")

    # --- сверка get_order (страховка к user-WS)
    async def recon_loop(self) -> None:
        m = self.m
        while time.time() < m.end:
            await asyncio.sleep(Cfg.RECON_S)
            await self.recon("recon")

    async def recon(self, src: str) -> None:
        live = [o for o in self.orders if o.get("oid") and o["matched"] < o["shares"] - 1e-9]
        rs = await asyncio.gather(*[asyncio.to_thread(self.clob.order, o["oid"]) for o in live], return_exceptions=True)
        for o, r in zip(live, rs):
            if isinstance(r, dict):
                sm = _num(r, "size_matched", "sizeMatched")
                if sm is not None:
                    self.on_matched(o, sm, src)

    def handle_user(self, raw) -> None:
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", "ignore")
        if not raw or raw.strip() in ("PING", "PONG"):
            return
        try:
            msg = json.loads(raw)
        except Exception:
            return
        for ev in (msg if isinstance(msg, list) else [msg]):
            if not isinstance(ev, dict) or ev.get("event_type") != "order":
                continue
            self.last_user_ev = time.time()
            o = self.by_id.get(ev.get("id"))
            sm = _fnum(ev.get("size_matched"))
            if o is not None and sm is not None:
                self.on_matched(o, sm, "ws")

    # --- итог
    def book_winner(self) -> Optional[str]:
        return book_winner_tail(self.tail, self.m.end)

    async def finish(self, gamma: Gamma) -> None:
        m = self.m
        await asyncio.sleep(max(0.0, m.end + 1 - time.time()))
        if self.taker_tasks:
            await asyncio.gather(*self.taker_tasks, return_exceptions=True)
        if self.clob.enabled and self.placed:
            await self.recon("final")                      # поздние филлы, которых не принёс WS
        await asyncio.sleep(0.5)
        traded = any(p["shares"] > 0 for p in self.pos.values())
        if not traded:
            await self.j.write({"event": "no_fills", "slug": m.slug, "placed": self.placed})
            return
        w, src = (self.book_winner() if Cfg.RESOLVE_BY_BOOK else None), "book"
        if not w:
            src = "gamma"
            await asyncio.sleep(Cfg.RESOLVE_DELAY_S)
            deadline = time.time() + Cfg.RESOLVE_TIMEOUT_S
            while time.time() < deadline and not w:
                w = await asyncio.to_thread(gamma.winner, m.slug)
                if not w:
                    await asyncio.sleep(30)
            if not w:
                await self.j.write({"event": "unresolved", "slug": m.slug})
                log.error("%s: исход не получен", m.slug)
                return
        await self.settle(w, src)
        if src == "book":
            spawn(self.verify(gamma, w))

    def pnl(self, w: str) -> Tuple[float, float, float]:
        usd = sum(p["usdc"] for p in self.pos.values())
        fee = sum(p["fee"] for p in self.pos.values())
        return (self.pos[w]["shares"] - usd - fee), usd, fee

    async def settle(self, w: str, src: str, fix: bool = False) -> None:
        pnl, usd, fee = self.pnl(w)
        if not fix:
            self.stats.add(usd, pnl)
        await self.j.write({"event": "resolved_fix" if fix else "resolved", "slug": self.m.slug, "winner": w,
                            "source": src, "usdc": round(usd, 4), "fee": round(fee, 4), "pnl": round(pnl, 4),
                            "up_usdc": round(self.pos["Up"]["usdc"], 4), "up_shares": round(self.pos["Up"]["shares"], 4),
                            "down_usdc": round(self.pos["Down"]["usdc"], 4),
                            "down_shares": round(self.pos["Down"]["shares"], 4),
                            "fills": sum(1 for o in self.orders if o["matched"] > 0),
                            "paper": not self.clob.enabled})
        log.warning("%s %s: победил %s (%s) → P&L %+.2f на $%.2f | %s", "ИСПРАВЛЕНИЕ" if fix else "РЕЗОЛВ",
                    self.m.slug, w, src, pnl, usd, self.stats.line())

    async def verify(self, gamma: Gamma, book_w: str) -> None:
        await asyncio.sleep(Cfg.RESOLVE_DELAY_S)
        deadline = time.time() + Cfg.RESOLVE_TIMEOUT_S
        g = None
        while time.time() < deadline and not g:
            g = await asyncio.to_thread(gamma.winner, self.m.slug)
            if not g:
                await asyncio.sleep(60)
        await self.j.write({"event": "gamma_check", "slug": self.m.slug, "book": book_w, "gamma": g,
                            "match": (g == book_w) if g else None})
        if g and g != book_w:
            old, new = self.pnl(book_w)[0], self.pnl(g)[0]
            self.stats.pnl += new - old
            await self.settle(g, "gamma", fix=True)


class Stats:
    def __init__(self):
        self.n = 0
        self.usd = self.pnl = 0.0

    def add(self, usd, pnl):
        self.n += 1
        self.usd += usd
        self.pnl += pnl

    def line(self) -> str:
        return f"сессия: рынков с филлами {self.n}, вложено ${self.usd:.2f}, P&L ${self.pnl:+.2f}"


# ════════════════════════════════════════════════════════════════ WS
def handle(raw, eng: Engine, now: float) -> None:
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", "ignore")
    if not raw or raw.strip() in ("PING", "PONG"):
        return
    try:
        msg = json.loads(raw)
    except Exception:
        return
    for ev in (msg if isinstance(msg, list) else [msg]):
        if not isinstance(ev, dict):
            continue
        et = ev.get("event_type")
        if et == "book":
            eng.set_book(ev.get("asset_id"), ev.get("bids"), ev.get("asks"))
        elif et == "price_change":
            for ch in ev.get("price_changes") or []:
                p, sz = _fnum(ch.get("price")), _fnum(ch.get("size"))
                if p is not None and sz is not None and ch.get("side"):
                    eng.on_levels(ch.get("asset_id"), str(ch.get("side")).upper(), p, sz)
        elif et == "tick_size_change" and ev.get("new_tick_size"):
            eng.m.tick = str(ev["new_tick_size"])
    eng.snap(now)


async def watch_market(eng: Engine, stop: asyncio.Event) -> None:
    m = eng.m
    toks = list(m.tokens.values())
    while not stop.is_set() and time.time() < m.end:
        try:
            async with websockets.connect(Cfg.WS_URL, ping_interval=None, close_timeout=5, max_size=2 ** 23) as ws:
                await ws.send(json.dumps({"assets_ids": toks, "type": "market"}))
                pinger = spawn(_pinger(ws, stop, 10.0, m.end))
                last = time.time()
                try:
                    while not stop.is_set() and time.time() < m.end:
                        try:
                            raw = await asyncio.wait_for(ws.recv(), timeout=max(1.0, min(Cfg.WS_STALE_S, m.end - time.time())))
                        except asyncio.TimeoutError:
                            if time.time() - last > Cfg.WS_STALE_S:
                                log.warning("%s: книга молчит, переподключаюсь", m.slug)
                                break
                            continue
                        last = time.time()
                        handle(raw, eng, last)
                finally:
                    pinger.cancel()
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("%s WS(market): %s", m.slug, e)
            await asyncio.sleep(1.0)


async def watch_user(eng: Engine, stop: asyncio.Event) -> None:
    """user-канал: order-события (size_matched) нашей сетки. Только боевой режим."""
    m, c = eng.m, eng.clob.creds
    auth = {"apiKey": getattr(c, "api_key", None), "secret": getattr(c, "api_secret", None),
            "passphrase": getattr(c, "api_passphrase", None)}
    while not stop.is_set() and time.time() < m.end + 2:
        try:
            async with websockets.connect(Cfg.WS_USER_URL, ping_interval=None, close_timeout=5, max_size=2 ** 22) as ws:
                await ws.send(json.dumps({"auth": auth, "type": "user", "markets": [m.cond]}))
                pinger = spawn(_pinger(ws, stop, 10.0, m.end + 2))
                try:
                    while not stop.is_set() and time.time() < m.end + 2:
                        try:
                            raw = await asyncio.wait_for(ws.recv(), timeout=5)
                        except asyncio.TimeoutError:
                            continue
                        eng.handle_user(raw)
                finally:
                    pinger.cancel()
            # после обрыва — сразу сверка, чтобы не пропустить филл
            await eng.recon("recon_after_reconnect")
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("%s WS(user): %s", m.slug, e)
            await asyncio.sleep(1.0)


async def run_engine(eng: Engine, gamma: Gamma, stop: asyncio.Event) -> None:
    m = eng.m
    log.info("слежу за %s: старт через %.0f с, конец %s", m.slug, m.start - time.time(),
             time.strftime("%H:%M:%S", time.gmtime(m.end)))
    fin = spawn(eng.finish(gamma))
    spawn(watch_market(eng, stop))
    await asyncio.sleep(0.4)                           # дать книге прийти (нужна для бумаги и справки)
    await eng.place_ladder()
    if eng.placed:
        if eng.clob.enabled:
            spawn(watch_user(eng, stop))
            spawn(eng.recon_loop())
        else:
            spawn(eng.paper_loop())
    try:
        await fin
    except Exception as e:
        log.error("%s завершение: %s", m.slug, e)


# ════════════════════════════════════════════════════════════════ main
ENG: Dict[str, Engine] = {}


async def main() -> None:
    logging.basicConfig(level=getattr(logging, Cfg.LOG_LEVEL.upper(), logging.INFO),
                        format="%(asctime)s %(levelname)-7s %(message)s", datefmt="%H:%M:%S")
    log.info("конфиг: %s", ENV_FILE_USED or "файл не найден — умолчания")
    log.warning("РЕЖИМ: %s", "БУМАЖНЫЙ" if Cfg.PAPER else "БОЕВОЙ — ордера уходят на биржу")
    per_market = 2 * len(Cfg.LEVELS) * Cfg.LIMIT_USDC
    log.info("%s | TF %s | сетка %s × $%g на уровень и исход → резерв ~$%.0f на рынок", Cfg.ASSETS, Cfg.TFS,
             ",".join(f"{x:g}" for x in Cfg.LEVELS), Cfg.LIMIT_USDC, per_market)
    log.info("тейкер: %s%s, потолок FAK = 1 − цена + %.2f (≤ %.2f), предподпись %s", Cfg.TAKER_MODE,
             f" ×{Cfg.TAKER_MULT:g}" if Cfg.TAKER_MODE == "usdc" else "", Cfg.TAKER_SLIP, Cfg.CAP_PX,
             "вкл" if Cfg.PRESIGN else "выкл")
    stop = asyncio.Event()
    try:
        import signal as _sig
        loop = asyncio.get_running_loop()
        for sg in (_sig.SIGINT, _sig.SIGTERM):
            loop.add_signal_handler(sg, stop.set)
    except Exception:
        pass
    clob, gamma, j, stats = Clob(), Gamma(), Journal(Cfg.JOURNAL), Stats()
    while not stop.is_set():
        now = time.time()
        for tf in Cfg.TFS:
            L = tf * 60
            lead = lead_for(tf)
            cur = int(now // L) * L
            for start in range(cur, int(now + lead) + L, L):
                if start + L <= now or start - now > lead:
                    continue
                for a in Cfg.ASSETS:
                    slug = f"{a}-updown-{tf}m-{start}"
                    if slug in ENG:
                        continue
                    mk = await asyncio.to_thread(gamma.market, a, tf, start)
                    if mk is None:
                        continue
                    eng = Engine(mk, clob, j, stats)
                    ENG[slug] = eng
                    spawn(run_engine(eng, gamma, stop))
        for slug in [s for s in ENG if int(s.rsplit("-", 1)[1]) < now - 7200]:
            ENG.pop(slug, None)
        try:
            await asyncio.wait_for(stop.wait(), timeout=1)
        except asyncio.TimeoutError:
            pass
    log.info("останавливаюсь. %s", stats.line())


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
